# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 12:07:21 2018

@author: MUJ
"""

import pandas as pd

warehouse_dataset = pd.read_excel("warehouse_dataset.xlsx")

warehouse_features = warehouse_dataset.iloc[:,[0,1,2,3]].values
warehouse_labels = warehouse_dataset.iloc[:,4].values

from sklearn.model_selection import train_test_split
warehouse_features_train,warehouse_features_test,warehouse_labels_train,warehouse_labels_test = train_test_split(warehouse_features,warehouse_labels,test_size = 0.2,random_state = 0)

from sklearn.linear_model import LinearRegression
warehouse_regressor = LinearRegression()
warehouse_regressor.fit(warehouse_features_train,warehouse_labels_train)

pred_warehouse = pd.read_excel("pred_warehouse.xlsx")

pred_warehouse["predicted_sales"] = warehouse_regressor.predict(pred_warehouse)

"""for index,rows in pred_warehouse.iterrows() :
    print(rows['product_id'], rows['predicted_sales'])"""
    
main_list = list()
product_id_list = list()
#my_dict = dict()
#for index,rows in pred_warehouse.iterrows() :
 #   if(rows["product_id"] in my_dict) :
  #      if main_list[rows["product_id"]]:
   
for i in range(13) :
    main_list.append(0)
    product_id_list.append(0)

for index,rows in pred_warehouse.iterrows() :
    if(main_list[int(rows["product_id"])]==0):
        main_list[int(rows["product_id"])]=rows["warehouse_id"]
        product_id_list[int(rows["product_id"])] = rows["predicted_sales"]
    
    else :
        if(product_id_list[int(rows["product_id"])] < rows["predicted_sales"]) :
            product_id_list[int(rows["product_id"])] = rows["predicted_sales"]
            main_list[int(rows["product_id"])] = rows["warehouse_id"]
            
            
    
    
    