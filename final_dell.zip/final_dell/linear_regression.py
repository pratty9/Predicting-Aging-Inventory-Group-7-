# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 09:17:05 2018

@author: hp
"""



import pandas as pd
import numpy as np

dataset1 = pd.read_excel("dataset11.xlsx")
features = dataset1.iloc[:,[0,2,3]]
labels = dataset1.iloc[:,4]

from sklearn.model_selection import train_test_split
features_train,features_test,labels_train,labels_test=train_test_split(features,labels,test_size=0.2,random_state=0)

from sklearn.linear_model import LinearRegression
regressor1 = LinearRegression()
regressor1.fit(features_train,labels_train)

regressor1.score(features_test,labels_test)

features_pred = pd.read_excel("dataset1_pred.xlsx")
regressor1.predict(features_pred)

features_pred["predicted_sales"] = regressor1.predict(features_pred)

features_pred.to_csv("pred_dataset1.csv")


"""2 dataset"""

dataset2 = pd.read_excel("dataset2.xlsx")
features2 = dataset2.iloc[:,[0,2,3]]
labels2 = dataset2.iloc[:,4]

features2_train,features2_test,labels2_train,labels2_test=train_test_split(features2,labels2,test_size=0.2,random_state=0)

regressor2 = LinearRegression()
regressor2.fit(features2_train,labels2_train)

regressor2.score(features2_test,labels2_test)

features_pred2 = pd.read_excel("dataset2_pred.xlsx")
regressor2.predict(features_pred2)

features_pred2["predicted_sales"] = regressor2.predict(features_pred2)

features_pred2.to_csv("pred_dataset2.csv")



"""3 dataset"""

dataset3 = pd.read_excel("dataset3.xlsx")
features3 = dataset3.iloc[:,[0,2,3]]
labels3 = dataset3.iloc[:,4]

features3_train,features3_test,labels3_train,labels3_test=train_test_split(features3,labels3,test_size=0.2,random_state=0)

regressor3 = LinearRegression()
regressor3.fit(features3_train,labels3_train)

regressor3.score(features3_test,labels3_test)

features_pred3 = pd.read_excel("dataset3_pred.xlsx")
regressor3.predict(features_pred3)

features_pred3["predicted_sales"] = regressor3.predict(features_pred3)

features_pred3.to_csv("pred_dataset3.csv")

"""4 dataset"""

dataset4 = pd.read_excel("DATASET4.xlsx")

features4 = dataset4.iloc[:,[0,2,4,7]]
labels4 = dataset4.iloc[:,5]

features4_train,features4_test,labels4_train,labels4_test = train_test_split(features4,labels4,test_size=0.2,random_state=0)

regressor4 = LinearRegression()
regressor4.fit(features4_train,labels4_train)

regressor4.score(features4_test,labels4_test)

features_pred4 = pd.read_excel("dataset4_pred.xlsx")
regressor4.predict(features_pred4)

features_pred4["predicted_sales"] = regressor4.predict(features_pred4)
features_pred4.to_csv("pred_dataset4.csv")